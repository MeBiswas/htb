module.exports = function(grunt) {
  return {
    publish: {
      command: 'npm publish'
    }
  };
};